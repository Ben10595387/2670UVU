﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResetPosition : MonoBehaviour {

	public Transform initialPoint; 

	// Use this for initialization
	void Start () {
//		EndGame.End += ResetObject;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
