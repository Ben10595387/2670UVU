﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class diedRespawn : MonoBehaviour {

	public Vector3 spawnPoint;

	void OnTriggerEnter(Collider other){
		
		if (other.tag == "Player")
			other.transform.root.position = spawnPoint;
	}

}
